-- Simple database creation script for XAMPP
-- Run this first in phpMyAdmin

CREATE DATABASE IF NOT EXISTS adfc_portal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE adfc_portal;

SELECT 'Database adfc_portal created successfully!' as message;