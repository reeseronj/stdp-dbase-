# XAMPP Database Installation Guide

## Step-by-Step Database Setup

### 1. Start XAMPP Services
- Open XAMPP Control Panel
- Start **Apache** and **MySQL** services
- Wait for both to show "Running" status

### 2. Access phpMyAdmin
- Open your browser
- Go to: `http://localhost/phpmyadmin`
- Login with username: `root` (no password)

### 3. Create Database
**Option A: Import Complete Setup**
1. Click "Import" tab in phpMyAdmin
2. Choose file: `database/setup.sql`
3. Click "Go" - this creates everything at once

**Option B: Step by Step**
1. Click "Import" and run `database/create_database.sql`
2. Then import `database/setup.sql`
3. Optionally import `database/sample_data.sql` for more test data

### 4. Verify Installation
- Database `adfc_portal` should appear in left sidebar
- Click on it to see tables: `users`, `grades`, `announcements`
- Check that data exists in the tables

### 5. Test the Portal
- Open: `http://localhost/adfc-portal/test_xampp.php`
- Should show all green checkmarks ✅
- Then go to: `http://localhost/adfc-portal/`

## Default Login Accounts

### Administrator
- **Username:** admin
- **Password:** admin123

### Students (for testing)
- **Username:** juan2024, **Password:** password
- **Username:** maria2024, **Password:** password
- **Username:** jose2024, **Password:** password

## Troubleshooting

### If Database Connection Fails:
1. Check MySQL is running in XAMPP
2. Verify `config/database.php` settings:
   - Host: localhost
   - Username: root
   - Password: (empty)
   - Database: adfc_portal

### If Tables Don't Exist:
- Re-import `database/setup.sql` in phpMyAdmin
- Make sure you selected the correct database

### If Login Doesn't Work:
- Check that user data exists in the `users` table
- Verify passwords are hashed correctly
- Try the test accounts listed above

## File Structure Created:
```
database/
├── setup.sql           (Complete database setup)
├── create_database.sql (Database creation only)
├── sample_data.sql     (Additional test data)
└── xampp_install_guide.md (This guide)
```