-- ADFC Portal - Quick Setup for XAMPP
-- Import this single file in phpMyAdmin to set up everything

CREATE DATABASE IF NOT EXISTS adfc_portal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE adfc_portal;

-- Users table (students and admin)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('student', 'admin') DEFAULT 'student',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Grades table
CREATE TABLE grades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL,
    course_code VARCHAR(20) NOT NULL,
    course_title VARCHAR(100) NOT NULL,
    units INT NOT NULL DEFAULT 3,
    grade VARCHAR(5) NOT NULL,
    grade_points DECIMAL(3,2) NOT NULL,
    semester VARCHAR(20) NOT NULL,
    academic_year VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(student_id) ON DELETE CASCADE
);

-- Announcements table
CREATE TABLE announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    type ENUM('general', 'academic', 'administrative') DEFAULT 'general',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert admin user (username: admin, password: admin123)
INSERT INTO users (student_id, full_name, email, username, password, role, status) VALUES
('ADMIN001', 'System Administrator', 'admin@adfc.edu', 'admin', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', 'admin', 'active');

-- Insert sample students (password: password for all)
INSERT INTO users (student_id, full_name, email, username, password, role, status) VALUES
('2024001', 'Joshua Reyes', 'joshua.reyes@student.adfc.edu', 'joshuareyes', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'active'),
('2024002', 'Maria Santos', 'maria.santos@student.adfc.edu', 'maria2024', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'active'),
('2024003', 'Jose Rizal', 'jose.rizal@student.adfc.edu', 'jose2024', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'active');

-- Insert sample grades
INSERT INTO grades (student_id, course_code, course_title, units, grade, grade_points, semester, academic_year) VALUES
('2024001', 'CS101', 'Introduction to Computer Science', 3, 'A', 4.0, '1st Semester', '2024-2025'),
('2024001', 'MATH101', 'College Algebra', 3, 'B+', 3.5, '1st Semester', '2024-2025'),
('2024001', 'ENG101', 'English Communication', 3, 'A-', 3.75, '1st Semester', '2024-2025'),
('2024002', 'CS101', 'Introduction to Computer Science', 3, 'B', 3.0, '1st Semester', '2024-2025'),
('2024002', 'MATH101', 'College Algebra', 3, 'A', 4.0, '1st Semester', '2024-2025'),
('2024003', 'CS101', 'Introduction to Computer Science', 3, 'A+', 4.0, '1st Semester', '2024-2025');

-- Insert sample announcements
INSERT INTO announcements (title, content, type, created_by) VALUES
('Welcome to BLOCK 8 Portal', 'Welcome to the Asian Development Foundation College student portal. Here you can view your grades, academic records, and important announcements.', 'general', 1),
('Final Examinations Schedule', 'Final examinations will begin next week. Please check your individual schedules and prepare accordingly.', 'academic', 1),
('System Maintenance Notice', 'The portal will undergo maintenance this weekend from 12:00 AM to 6:00 AM on Sunday.', 'administrative', 1);

-- Success message
SELECT 'ADFC Portal database setup completed successfully!' as Status;
SELECT 'Admin login: username=admin, password=admin123' as AdminAccount;
SELECT 'Student login: username=juan2024, password=password' as StudentAccount;