-- Database setup for ADFC Student Portal
-- Run this script in phpMyAdmin or MySQL command line

-- Create database
CREATE DATABASE IF NOT EXISTS adfc_portal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE adfc_portal;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('student', 'admin') DEFAULT 'student',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create grades table
CREATE TABLE IF NOT EXISTS grades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL,
    course_code VARCHAR(20) NOT NULL,
    course_title VARCHAR(100) NOT NULL,
    units INT NOT NULL DEFAULT 3,
    grade VARCHAR(5) NOT NULL,
    grade_points DECIMAL(3,2) NOT NULL,
    semester VARCHAR(20) NOT NULL,
    academic_year VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(student_id) ON DELETE CASCADE
);

-- Create announcements table
CREATE TABLE IF NOT EXISTS announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    type ENUM('general', 'academic', 'administrative') DEFAULT 'general',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Create sessions table for better session management
CREATE TABLE IF NOT EXISTS user_sessions (
    id VARCHAR(128) PRIMARY KEY,
    user_id INT NOT NULL,
    data TEXT,
    expires INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert default admin user
-- Username: admin, Password: admin123
INSERT INTO users (student_id, full_name, email, username, password, role, status) 
VALUES ('ADMIN001', 'System Administrator', 'admin@adfc.edu', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active')
ON DUPLICATE KEY UPDATE username = username;

-- Insert sample student data (optional - remove if you don't want sample data)
INSERT INTO users (student_id, full_name, email, username, password, role, status) VALUES
('2024001', 'Juan Dela Cruz', 'juan.delacruz@student.adfc.edu', 'juan2024', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'active'),
('2024002', 'Maria Santos', 'maria.santos@student.adfc.edu', 'maria2024', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'active'),
('2024003', 'Jose Rizal', 'jose.rizal@student.adfc.edu', 'jose2024', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'active')
ON DUPLICATE KEY UPDATE username = username;

-- Insert sample grades (optional - remove if you don't want sample data)
INSERT INTO grades (student_id, course_code, course_title, units, grade, grade_points, semester, academic_year) VALUES
('2024001', 'CS101', 'Introduction to Computer Science', 3, 'A', 4.0, '1st Semester', '2024-2025'),
('2024001', 'MATH101', 'College Algebra', 3, 'B+', 3.5, '1st Semester', '2024-2025'),
('2024001', 'ENG101', 'English Communication', 3, 'A-', 3.75, '1st Semester', '2024-2025'),
('2024002', 'CS101', 'Introduction to Computer Science', 3, 'B', 3.0, '1st Semester', '2024-2025'),
('2024002', 'MATH101', 'College Algebra', 3, 'A', 4.0, '1st Semester', '2024-2025'),
('2024003', 'CS101', 'Introduction to Computer Science', 3, 'A+', 4.0, '1st Semester', '2024-2025')
ON DUPLICATE KEY UPDATE course_code = course_code;

-- Insert sample announcements
INSERT INTO announcements (title, content, type, created_by) VALUES
('Welcome to BLOCK 8 Portal', 'Welcome to the Asian Development Foundation College student portal. Here you can view your grades, academic records, and important announcements.', 'general', 1),
('Final Examinations Schedule', 'Final examinations will begin next week. Please check your individual schedules and prepare accordingly.', 'academic', 1),
('System Maintenance Notice', 'The portal will undergo maintenance this weekend from 12:00 AM to 6:00 AM on Sunday.', 'administrative', 1)
ON DUPLICATE KEY UPDATE title = title;

-- Create indexes for better performance
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_student_id ON users(student_id);
CREATE INDEX idx_grades_student_id ON grades(student_id);
CREATE INDEX idx_grades_semester ON grades(semester);
CREATE INDEX idx_announcements_status ON announcements(status);
CREATE INDEX idx_user_sessions_expires ON user_sessions(expires);

-- Create a view for student grade summary
CREATE VIEW student_grade_summary AS
SELECT 
    u.student_id,
    u.full_name,
    COUNT(g.id) as total_courses,
    SUM(g.units) as total_units,
    ROUND(SUM(g.grade_points * g.units) / SUM(g.units), 2) as gpa,
    u.status
FROM users u
LEFT JOIN grades g ON u.student_id = g.student_id
WHERE u.role = 'student'
GROUP BY u.id, u.student_id, u.full_name, u.status;

-- Create stored procedure for calculating GPA
DELIMITER //
CREATE PROCEDURE CalculateStudentGPA(IN student_id_param VARCHAR(20), OUT gpa_result DECIMAL(3,2))
BEGIN
    SELECT ROUND(SUM(grade_points * units) / SUM(units), 2) 
    INTO gpa_result
    FROM grades 
    WHERE student_id = student_id_param;
END //
DELIMITER ;

-- Create trigger to update timestamp on user changes
DELIMITER //
CREATE TRIGGER update_user_timestamp 
BEFORE UPDATE ON users
FOR EACH ROW
BEGIN
    SET NEW.updated_at = CURRENT_TIMESTAMP;
END //
DELIMITER ;

-- Create trigger to update timestamp on grade changes
DELIMITER //
CREATE TRIGGER update_grade_timestamp 
BEFORE UPDATE ON grades
FOR EACH ROW
BEGIN
    SET NEW.updated_at = CURRENT_TIMESTAMP;
END //
DELIMITER ;

-- Grant necessary permissions (adjust as needed for your setup)
-- GRANT SELECT, INSERT, UPDATE, DELETE ON adfc_portal.* TO 'adfc_user'@'localhost' IDENTIFIED BY 'adfc_password';
-- FLUSH PRIVILEGES;

-- Display setup completion message
SELECT 'Database setup completed successfully!' as message;
SELECT 'Default admin credentials: username = admin, password = admin123' as admin_info;
SELECT 'Default student credentials: username = juan2024, password = password (for testing)' as student_info;
