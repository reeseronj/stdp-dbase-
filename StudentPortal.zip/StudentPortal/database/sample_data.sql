-- Sample data for testing the ADFC Portal
-- Run this after setup.sql to add test data

USE adfc_portal;

-- Additional sample students
INSERT INTO users (student_id, full_name, email, username, password, role, status) VALUES
('2024004', 'Anna Garcia', 'anna.garcia@student.adfc.edu', 'anna2024', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'active'),
('2024005', 'Carlos Rodriguez', 'carlos.rodriguez@student.adfc.edu', 'carlos2024', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'active'),
('2024006', 'Lisa Fernandez', 'lisa.fernandez@student.adfc.edu', 'lisa2024', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'active')
ON DUPLICATE KEY UPDATE username = username;

-- Additional sample grades
INSERT INTO grades (student_id, course_code, course_title, units, grade, grade_points, semester, academic_year) VALUES
('2024001', 'CS102', 'Data Structures', 3, 'B+', 3.5, '1st Semester', '2024-2025'),
('2024001', 'PHYS101', 'Physics for Engineers', 4, 'A-', 3.75, '1st Semester', '2024-2025'),
('2024002', 'ENG101', 'English Communication', 3, 'A-', 3.75, '1st Semester', '2024-2025'),
('2024002', 'HIST101', 'Philippine History', 3, 'B', 3.0, '1st Semester', '2024-2025'),
('2024003', 'MATH101', 'College Algebra', 3, 'A', 4.0, '1st Semester', '2024-2025'),
('2024003', 'ENG101', 'English Communication', 3, 'B+', 3.5, '1st Semester', '2024-2025'),
('2024004', 'CS101', 'Introduction to Computer Science', 3, 'A', 4.0, '1st Semester', '2024-2025'),
('2024004', 'MATH101', 'College Algebra', 3, 'A-', 3.75, '1st Semester', '2024-2025'),
('2024005', 'CS101', 'Introduction to Computer Science', 3, 'B', 3.0, '1st Semester', '2024-2025'),
('2024006', 'ENG101', 'English Communication', 3, 'A+', 4.0, '1st Semester', '2024-2025')
ON DUPLICATE KEY UPDATE course_code = course_code;

SELECT 'Sample data inserted successfully!' as message;
SELECT 'Total students:', COUNT(*) FROM users WHERE role = 'student';
SELECT 'Total grades:', COUNT(*) FROM grades;