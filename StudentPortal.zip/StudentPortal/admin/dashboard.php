<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

// Get statistics
$stmt = $pdo->query("SELECT COUNT(*) as total_students FROM users WHERE role = 'student'");
$total_students = $stmt->fetch()['total_students'];

$stmt = $pdo->query("SELECT COUNT(*) as total_grades FROM grades");
$total_grades = $stmt->fetch()['total_grades'];

$stmt = $pdo->query("SELECT COUNT(DISTINCT student_id) as students_with_grades FROM grades");
$students_with_grades = $stmt->fetch()['students_with_grades'];

include '../includes/header.php';
?>

<body style="background: #f5f5f5;">

<div class="dashboard-container">
    <div class="nav">
        <div>
            <h4 style="margin: 0; color: white;">
                <i class="fas fa-user-shield"></i> Admin Dashboard - <?php echo htmlspecialchars($_SESSION['full_name']); ?>
            </h4>
        </div>
        <div>
            <a href="manage_students.php" class="btn btn-light btn-sm me-2">
                <i class="fas fa-users"></i> Manage Students
            </a>
            <a href="../auth/logout.php" class="btn btn-light btn-sm">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-3">
            <div class="card text-white bg-primary mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5 class="card-title">Total Students</h5>
                            <h2><?php echo $total_students; ?></h2>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-users fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-white bg-success mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5 class="card-title">Total Grades</h5>
                            <h2><?php echo $total_grades; ?></h2>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-graduation-cap fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-white bg-info mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5 class="card-title">Students with Grades</h5>
                            <h2><?php echo $students_with_grades; ?></h2>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-chart-line fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-white bg-warning mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5 class="card-title">Pending Tasks</h5>
                            <h2>5</h2>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-tasks fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" style="background-color: #1e549f; color: white;">
                    <h5><i class="fas fa-users"></i> Recent Student Registrations</h5>
                </div>
                <div class="card-body">
                    <?php
                    $stmt = $pdo->query("SELECT * FROM users WHERE role = 'student' ORDER BY created_at DESC LIMIT 10");
                    $recent_students = $stmt->fetchAll();
                    ?>
                    
                    <?php if (!empty($recent_students)): ?>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Student ID</th>
                                    <th>Full Name</th>
                                    <th>Email</th>
                                    <th>Username</th>
                                    <th>Registration Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_students as $student): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                    <td><?php echo htmlspecialchars($student['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($student['email']); ?></td>
                                    <td><?php echo htmlspecialchars($student['username']); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($student['created_at'])); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $student['status'] === 'active' ? 'success' : 'warning'; ?>">
                                            <?php echo ucfirst($student['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> No students registered yet.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header" style="background-color: #1e549f; color: white;">
                    <h5><i class="fas fa-cog"></i> Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="manage_students.php" class="btn btn-primary">
                            <i class="fas fa-users"></i> Manage Students
                        </a>
                        <button class="btn btn-success" onclick="alert('Grade management feature coming soon!')">
                            <i class="fas fa-plus"></i> Add Grades
                        </button>
                        <button class="btn btn-info" onclick="alert('Report generation feature coming soon!')">
                            <i class="fas fa-chart-bar"></i> Generate Reports
                        </button>
                        <button class="btn btn-warning" onclick="alert('Announcement feature coming soon!')">
                            <i class="fas fa-bullhorn"></i> Post Announcement
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header" style="background-color: #1e549f; color: white;">
                    <h5><i class="fas fa-chart-pie"></i> System Overview</h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-success">
                        <strong>System Status:</strong> All services running normally
                    </div>
                    <div class="alert alert-info">
                        <strong>Last Backup:</strong> <?php echo date('M d, Y H:i'); ?>
                    </div>
                    <div class="alert alert-warning">
                        <strong>Maintenance:</strong> Scheduled for this weekend
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
