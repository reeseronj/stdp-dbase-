<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'update_status') {
        $student_id = $_POST['student_id'];
        $new_status = $_POST['status'];
        
        $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $student_id]);
        
        $_SESSION['success'] = 'Student status updated successfully';
    }
    
    if ($_POST['action'] === 'delete_student') {
        $student_id = $_POST['student_id'];
        
        // Delete grades first (foreign key constraint)
        $stmt = $pdo->prepare("DELETE FROM grades WHERE student_id = (SELECT student_id FROM users WHERE id = ?)");
        $stmt->execute([$student_id]);
        
        // Delete user
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$student_id]);
        
        $_SESSION['success'] = 'Student deleted successfully';
    }
    
    header('Location: manage_students.php');
    exit();
}

// Get all students
$stmt = $pdo->query("SELECT * FROM users WHERE role = 'student' ORDER BY created_at DESC");
$students = $stmt->fetchAll();

include '../includes/header.php';
?>

<body style="background: #f5f5f5;">

<div class="dashboard-container">
    <div class="nav">
        <div>
            <h4 style="margin: 0; color: white;">
                <i class="fas fa-users"></i> Manage Students
            </h4>
        </div>
        <div>
            <a href="dashboard.php" class="btn btn-light btn-sm me-2">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
            <a href="../auth/logout.php" class="btn btn-light btn-sm">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header" style="background-color: #1e549f; color: white;">
            <h5><i class="fas fa-list"></i> Student List</h5>
        </div>
        <div class="card-body">
            <?php if (!empty($students)): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Username</th>
                                <th>Status</th>
                                <th>Registration Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($student['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($student['email']); ?></td>
                                <td><?php echo htmlspecialchars($student['username']); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo $student['status'] === 'active' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($student['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($student['created_at'])); ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <!-- Status Toggle Button -->
                                        <form method="post" style="display: inline;">
                                            <input type="hidden" name="action" value="update_status">
                                            <input type="hidden" name="student_id" value="<?php echo $student['id']; ?>">
                                            <input type="hidden" name="status" value="<?php echo $student['status'] === 'active' ? 'inactive' : 'active'; ?>">
                                            <button type="submit" class="btn btn-<?php echo $student['status'] === 'active' ? 'warning' : 'success'; ?>" 
                                                    onclick="return confirm('Are you sure you want to change this student\'s status?')">
                                                <i class="fas fa-<?php echo $student['status'] === 'active' ? 'pause' : 'play'; ?>"></i>
                                                <?php echo $student['status'] === 'active' ? 'Deactivate' : 'Activate'; ?>
                                            </button>
                                        </form>
                                        
                                        <!-- View Grades Button -->
                                        <button class="btn btn-info" onclick="viewGrades('<?php echo $student['student_id']; ?>', '<?php echo htmlspecialchars($student['full_name']); ?>')">
                                            <i class="fas fa-eye"></i> Grades
                                        </button>
                                        
                                        <!-- Delete Button -->
                                        <form method="post" style="display: inline;">
                                            <input type="hidden" name="action" value="delete_student">
                                            <input type="hidden" name="student_id" value="<?php echo $student['id']; ?>">
                                            <button type="submit" class="btn btn-danger" 
                                                    onclick="return confirm('Are you sure you want to delete this student? This action cannot be undone!')">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> No students registered yet.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Add Student Form -->
    <div class="card mt-4">
        <div class="card-header" style="background-color: #1e549f; color: white;">
            <h5><i class="fas fa-user-plus"></i> Add New Student</h5>
        </div>
        <div class="card-body">
            <form method="post" action="../auth/register.php">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="student_id" class="form-label">Student ID</label>
                            <input type="text" class="form-control" name="student_id" required>
                        </div>
                        <div class="mb-3">
                            <label for="full_name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" name="full_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" name="confirm_password" required>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add Student
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Grades Modal -->
<div class="modal fade" id="gradesModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #1e549f; color: white;">
                <h5 class="modal-title">Student Grades</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="gradesContent">
                <!-- Grades will be loaded here -->
            </div>
        </div>
    </div>
</div>

<script>
function viewGrades(studentId, studentName) {
    // Set modal title
    document.querySelector('#gradesModal .modal-title').textContent = 'Grades for ' + studentName;
    
    // Load grades via AJAX
    fetch('../api/get_grades.php?student_id=' + studentId)
        .then(response => response.json())
        .then(data => {
            let content = '';
            if (data.length > 0) {
                content = `
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Course Code</th>
                                <th>Course Title</th>
                                <th>Units</th>
                                <th>Grade</th>
                                <th>Grade Points</th>
                                <th>Semester</th>
                            </tr>
                        </thead>
                        <tbody>
                `;
                data.forEach(grade => {
                    content += `
                        <tr>
                            <td>${grade.course_code}</td>
                            <td>${grade.course_title}</td>
                            <td>${grade.units}</td>
                            <td>${grade.grade}</td>
                            <td>${grade.grade_points}</td>
                            <td>${grade.semester}</td>
                        </tr>
                    `;
                });
                content += '</tbody></table>';
            } else {
                content = '<div class="alert alert-info">No grades found for this student.</div>';
            }
            
            document.getElementById('gradesContent').innerHTML = content;
            new bootstrap.Modal(document.getElementById('gradesModal')).show();
        })
        .catch(error => {
            document.getElementById('gradesContent').innerHTML = '<div class="alert alert-danger">Error loading grades.</div>';
            new bootstrap.Modal(document.getElementById('gradesModal')).show();
        });
}
</script>

<?php include '../includes/footer.php'; ?>
