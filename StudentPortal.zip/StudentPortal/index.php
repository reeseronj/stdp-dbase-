<?php
session_start();

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: student/dashboard.php');
    }
    exit();
}

include 'includes/header.php';
?>

<body id="sign-in">
      
<div class="preloader" style="display: none;">
    <div class="loader_img"><img src="assets/images/adfc_logo.png" alt="loading..." height="64" width="64" style="display: none;"></div>
</div>

<!-- Login Page -->
<div id="login-page" class="flex-container">
    <div class="container"> 
        <div class="row row-inner-container"> 
            <div class="col-md-12">
                <div class="row my-form-row">
                    <div class="col-md-6 my-col"> 
                        <div class="logo-container">
                            <img class="img-logo" src="assets/images/adfc_logo.png" alt="Asian Development Foundation College logo">
                            <div class="logo-text"> Asian Development Foundation College </div>
                        </div> 
                    </div>
                    <div class="col-md-6 my-col">
                        <div class="my-form-container">
                            <div class="my-form-inner-container">
                                <div class="panel-header">
                                    <h2 class="text-center">
                                       BLOCK 8 PORTAL
                                    </h2> 
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <h3 style="font-weight: bold;margin-bottom: 20px;">Sign In</h3>
                                            
                                            <?php if (isset($_SESSION['error'])): ?>
                                                <div class="alert alert-danger" role="alert">
                                                    <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <?php if (isset($_SESSION['success'])): ?>
                                                <div class="alert alert-success" role="alert">
                                                    <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <form id="authentication" method="post" action="auth/login.php" class="login_validator">
                                                <div class="form-group mb-3">
                                                    <label for="username" class="sr-only">Username</label>  
                                                    <input required type="text" class="form-control form-control-lg" id="username" name="username" placeholder="Username">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="password" class="sr-only">Password</label>
                                                    <input required type="password" class="form-control form-control-lg" id="password" name="password" placeholder="Password">
                                                </div>

                                                <div class="form-group mb-3">
                                                    <button class="btn btn-primary btn-block btn-lg w-100" type="submit">Login</button>
                                                </div>
                                                <div class="clearfix"></div>
                                                <a href="#" id="forgot" class="forgot">Forgot Password?</a>
                                                <span class="float-end sign-up">New? <a href="#" onclick="showRegister()">Register</a></span>
                                            </form>
                                        </div>
                                        <div class="col-xs-12">
                                            <br><br>
                                            <p class="text-center">By using this service, you understood and agree to the <a href="#" target="_blank">ADFC Online Services Terms of Use and Privacy Statement</a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div> 
        </div>  
        <div class="row">  
            <div class="col-md-12"> 
                <p style="margin: 10px 0px"><a href="#"><small>← Back to Homepage</small></a></p>
            </div>
        </div> 
    </div> 
</div>

<!-- Registration Page -->
<div id="register-page" class="flex-container" style="display:none;">
    <div class="container"> 
        <div class="row row-inner-container"> 
            <div class="col-md-12">
                <div class="row my-form-row">
                    <div class="col-md-6 my-col"> 
                        <div class="logo-container">
                            <img class="img-logo" src="assets/images/adfc_logo.png" alt="Asian Development Foundation College logo">
                            <div class="logo-text"> Asian Development Foundation College </div>
                        </div> 
                    </div>
                    <div class="col-md-6 my-col">
                        <div class="my-form-container">
                            <div class="my-form-inner-container">
                                <div class="panel-header">
                                    <h2 class="text-center">
                                       BLOCK 8 PORTAL
                                    </h2> 
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <h3 style="font-weight: bold;margin-bottom: 20px;">Register</h3>
                                            <form id="registration" method="post" action="auth/register.php" class="register_validator">
                                                <div class="form-group mb-3">
                                                    <label for="student_id" class="sr-only">Student ID</label>  
                                                    <input required type="text" class="form-control form-control-lg" id="student_id" name="student_id" placeholder="Student ID">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="full_name" class="sr-only">Full Name</label>  
                                                    <input required type="text" class="form-control form-control-lg" id="full_name" name="full_name" placeholder="Full Name">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="email" class="sr-only">Email</label>  
                                                    <input required type="email" class="form-control form-control-lg" id="email" name="email" placeholder="Email Address">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="reg_username" class="sr-only">Username</label>  
                                                    <input required type="text" class="form-control form-control-lg" id="reg_username" name="username" placeholder="Username">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="reg_password" class="sr-only">Password</label>
                                                    <input required type="password" class="form-control form-control-lg" id="reg_password" name="password" placeholder="Password">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="confirm_password" class="sr-only">Confirm Password</label>
                                                    <input required type="password" class="form-control form-control-lg" id="confirm_password" name="confirm_password" placeholder="Confirm Password">
                                                </div>

                                                <div class="form-group mb-3">
                                                    <button class="btn btn-primary btn-block btn-lg w-100" type="submit">Register</button>
                                                </div>
                                                <div class="clearfix"></div>
                                                <span class="float-end sign-up">Already have an account? <a href="#" onclick="showLogin()">Sign In</a></span>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div> 
        </div>  
    </div> 
</div>

<?php include 'includes/footer.php'; ?>
