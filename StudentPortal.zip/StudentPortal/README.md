# ADFC Student Portal - XAMPP Installation Guide

A PHP/MySQL student portal system for Asian Development Foundation College designed to run on XAMPP.

## Features

- **Student Registration & Login**: Secure user authentication with password hashing
- **Admin Dashboard**: Comprehensive admin panel for managing students and grades
- **Student Dashboard**: Personal dashboard for viewing grades and academic records
- **Grade Management**: System for tracking and displaying student grades
- **Responsive Design**: Mobile-friendly interface that works on all devices
- **Secure Sessions**: Proper session management and security measures

## Installation Instructions

### Prerequisites

- XAMPP (Apache + MySQL + PHP 7.4 or higher)
- Web browser
- Text editor (optional, for customization)

### Step 1: Download and Install XAMPP

1. Download XAMPP from [https://www.apachefriends.org/](https://www.apachefriends.org/)
2. Install XAMPP on your system
3. Start Apache and MySQL services from XAMPP Control Panel

### Step 2: Setup the Application

1. **Copy Files**: 
   - Extract the portal files to your XAMPP `htdocs` directory
   - The folder structure should be: `C:\xampp\htdocs\adfc-portal\`

2. **Copy Images**:
   - Copy `adfc_background.jpg` to `assets/images/adfc_background.jpg`
   - Copy `adfc_logo.png` to `assets/images/adfc_logo.png`

### Step 3: Setup Database

1. **Access phpMyAdmin**:
   - Open your browser and go to `http://localhost/phpmyadmin`
   - Login with username `root` and no password

2. **Create Database**:
   - Click "Import" tab
   - Choose the file `database/setup.sql`
   - Click "Go" to execute the script
   - This will create the database and all necessary tables with sample data

3. **Verify Setup**:
   - Check that the database `adfc_portal` was created
   - Verify that tables `users`, `grades`, `announcements` exist

### Step 4: Configure Database Connection

1. Open `config/database.php`
2. Verify the database settings:
   ```php
   $host = 'localhost';
   $dbname = 'adfc_portal';
   $username = 'root';
   $password = '';
   ```
3. Adjust if your MySQL setup is different

### Step 5: Access the Portal

1. **Open the Portal**:
   - Go to `http://localhost/adfc-portal/`
   - You should see the login page

2. **Test Login**:
   - **Admin Login**: username: `admin`, password: `admin123`
   - **Student Login**: username: `juan2024`, password: `password`

## Default Accounts

### Administrator Account
- **Username**: admin
- **Password**: admin123
- **Role**: Admin
- **Access**: Full system administration

### Sample Student Accounts
- **Username**: juan2024, **Password**: password
- **Username**: maria2024, **Password**: password  
- **Username**: jose2024, **Password**: password

## File Structure

