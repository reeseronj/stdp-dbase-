# ADFC Student Portal - XAMPP Installation Guide

## Quick Setup for XAMPP

### Step 1: Copy Files to XAMPP
1. Copy ALL project files to your XAMPP htdocs folder: `C:\xampp\htdocs\adfc-portal\`
2. Make sure the images are in the correct location:
   - `assets/images/adfc_background.jpg`
   - `assets/images/adfc_logo.png`

### Step 2: Database Setup
1. Start XAMPP (Apache + MySQL)
2. Open phpMyAdmin: `http://localhost/phpmyadmin`
3. Import the database file: `database/setup.sql`

### Step 3: Test the Portal
1. Open: `http://localhost/adfc-portal/`
2. Login with:
   - **Admin**: username: `admin`, password: `admin123`
   - **Student**: username: `juan2024`, password: `password`

## File Structure for XAMPP
```
adfc-portal/
├── index.php (main login page)
├── config/
│   └── database.php
├── includes/
│   ├── header.php
│   └── footer.php
├── auth/
│   ├── login.php
│   ├── register.php
│   └── logout.php
├── student/
│   └── dashboard.php
├── admin/
│   ├── dashboard.php
│   └── manage_students.php
├── assets/
│   ├── css/style.css
│   ├── js/script.js
│   └── images/
│       ├── adfc_background.jpg
│       └── adfc_logo.png
└── database/
    └── setup.sql
```

## Default Login Credentials

### Administrator
- Username: `admin`
- Password: `admin123`

### Sample Students (for testing)
- Username: `juan2024`, Password: `password`
- Username: `maria2024`, Password: `password`
- Username: `jose2024`, Password: `password`

## Features Working
✅ User Authentication (Login/Register)
✅ Student Dashboard with grades
✅ Admin Dashboard with student management
✅ Responsive design preserved
✅ All original styling maintained
✅ Database with sample data
✅ Session management
✅ Password hashing security