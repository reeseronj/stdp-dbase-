<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ../index.php');
    exit();
}

// Get user information
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Get grades (example data structure)
$stmt = $pdo->prepare("SELECT * FROM grades WHERE student_id = ? ORDER BY created_at DESC");
$stmt->execute([$user['student_id']]);
$grades = $stmt->fetchAll();

include '../includes/header.php';
?>

<body style="background: #f5f5f5;">

<div class="dashboard-container">
    <div class="nav">
        <div>
            <h4 style="margin: 0; color: white;">
                <i class="fas fa-user-graduate"></i> Student Dashboard - <?php echo htmlspecialchars($user['full_name']); ?>
            </h4>
        </div>
        <div>
            <a href="../auth/logout.php" class="btn btn-light btn-sm">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header" style="background-color: #1e549f; color: white;">
                    <h5><i class="fas fa-user"></i> Profile Information</h5>
                </div>
                <div class="card-body">
                    <p><strong>Student ID:</strong> <?php echo htmlspecialchars($user['student_id']); ?></p>
                    <p><strong>Full Name:</strong> <?php echo htmlspecialchars($user['full_name']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                    <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header" style="background-color: #1e549f; color: white;">
                    <h5><i class="fas fa-chart-line"></i> Academic Summary</h5>
                </div>
                <div class="card-body">
                    <?php
                    if (!empty($grades)) {
                        $total_points = 0;
                        $total_units = 0;
                        foreach ($grades as $grade) {
                            $total_points += $grade['grade_points'] * $grade['units'];
                            $total_units += $grade['units'];
                        }
                        $gpa = $total_units > 0 ? round($total_points / $total_units, 2) : 0;
                        echo "<p><strong>Current GPA:</strong> $gpa</p>";
                        echo "<p><strong>Total Units:</strong> $total_units</p>";
                        echo "<p><strong>Courses Taken:</strong> " . count($grades) . "</p>";
                    } else {
                        echo "<p>No grades available yet.</p>";
                    }
                    ?>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style="background-color: #1e549f; color: white;">
                    <h5><i class="fas fa-graduation-cap"></i> Academic Records</h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($grades)): ?>
                        <table class="grades-table table table-striped">
                            <thead>
                                <tr>
                                    <th>Course Code</th>
                                    <th>Course Title</th>
                                    <th>Units</th>
                                    <th>Grade</th>
                                    <th>Grade Points</th>
                                    <th>Semester</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($grades as $grade): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($grade['course_code']); ?></td>
                                    <td><?php echo htmlspecialchars($grade['course_title']); ?></td>
                                    <td><?php echo htmlspecialchars($grade['units']); ?></td>
                                    <td><?php echo htmlspecialchars($grade['grade']); ?></td>
                                    <td><?php echo htmlspecialchars($grade['grade_points']); ?></td>
                                    <td><?php echo htmlspecialchars($grade['semester']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> No grades have been posted yet. Please check back later.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card mt-4">
                <div class="card-header" style="background-color: #1e549f; color: white;">
                    <h5><i class="fas fa-bell"></i> Announcements</h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-primary">
                        <strong>Welcome to BLOCK 8 Portal!</strong><br>
                        You can view your grades, academic records, and important announcements here.
                    </div>
                    <div class="alert alert-warning">
                        <strong>Reminder:</strong> Final examinations will begin next week. Please check your schedule.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
