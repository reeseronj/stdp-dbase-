<?php
// Fix admin login - generates correct password hash
// Run this file once to fix the admin password

require_once 'config/database.php';

// Generate correct password hash for "admin123"
$correct_hash = password_hash('admin123', PASSWORD_DEFAULT);

echo "<h2>Admin Login Fix</h2>";
echo "<p>Generated hash for password 'admin123': $correct_hash</p>";

try {
    // Update admin password in database
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE username = 'admin'");
    $result = $stmt->execute([$correct_hash]);
    
    if ($result) {
        echo "<p style='color: green;'>✅ Admin password updated successfully!</p>";
        
        // Verify the admin user exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = 'admin'");
        $stmt->execute();
        $admin = $stmt->fetch();
        
        if ($admin) {
            echo "<p style='color: green;'>✅ Admin user found in database</p>";
            echo "<p><strong>Admin Details:</strong></p>";
            echo "<ul>";
            echo "<li>ID: " . $admin['id'] . "</li>";
            echo "<li>Username: " . $admin['username'] . "</li>";
            echo "<li>Role: " . $admin['role'] . "</li>";
            echo "<li>Status: " . $admin['status'] . "</li>";
            echo "</ul>";
        } else {
            echo "<p style='color: red;'>❌ Admin user not found! Creating admin user...</p>";
            
            // Create admin user
            $stmt = $pdo->prepare("INSERT INTO users (student_id, full_name, email, username, password, role, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute(['ADMIN001', 'System Administrator', 'admin@adfc.edu', 'admin', $correct_hash, 'admin', 'active']);
            echo "<p style='color: green;'>✅ Admin user created successfully!</p>";
        }
        
    } else {
        echo "<p style='color: red;'>❌ Failed to update admin password</p>";
    }
    
} catch(Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<h3>Test Login Now:</h3>";
echo "<p><strong>Username:</strong> admin</p>";
echo "<p><strong>Password:</strong> admin123</p>";
echo "<p><a href='index.php'>→ Go to Login Page</a></p>";
?>