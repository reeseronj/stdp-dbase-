<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

if (!isset($_GET['student_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Student ID required']);
    exit();
}

$student_id = $_GET['student_id'];

try {
    $stmt = $pdo->prepare("SELECT * FROM grades WHERE student_id = ? ORDER BY semester, course_code");
    $stmt->execute([$student_id]);
    $grades = $stmt->fetchAll();
    
    header('Content-Type: application/json');
    echo json_encode($grades);
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}
?>