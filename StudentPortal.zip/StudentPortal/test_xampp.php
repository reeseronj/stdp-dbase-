<?php
// Test file to verify XAMPP setup is working
echo "<h1>ADFC Portal - XAMPP Test</h1>";
echo "<p>✅ PHP is working correctly!</p>";
echo "<p>PHP Version: " . phpversion() . "</p>";

// Test database connection
try {
    require_once 'config/database.php';
    echo "<p>✅ Database connection successful!</p>";
    
    // Test if tables exist
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (count($tables) > 0) {
        echo "<p>✅ Database tables found: " . implode(', ', $tables) . "</p>";
        
        // Test user count
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
        $userCount = $stmt->fetch()['count'];
        echo "<p>✅ Users in database: " . $userCount . "</p>";
        
    } else {
        echo "<p>⚠️ No tables found. Please import database/setup.sql</p>";
    }
    
} catch(Exception $e) {
    echo "<p>❌ Database connection failed: " . $e->getMessage() . "</p>";
    echo "<p>Please check your database configuration in config/database.php</p>";
}

// Test image files
$images = ['assets/images/adfc_logo.png', 'assets/images/adfc_background.jpg'];
foreach ($images as $image) {
    if (file_exists($image)) {
        echo "<p>✅ Image found: " . $image . "</p>";
    } else {
        echo "<p>❌ Image missing: " . $image . "</p>";
    }
}

echo "<br><a href='index.php'>→ Go to Login Page</a>";
?>