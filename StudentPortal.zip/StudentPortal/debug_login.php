<?php
// Debug admin login issue
require_once 'config/database.php';

echo "<h2>Admin Login Debug</h2>";

try {
    // Check if admin user exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = 'admin'");
    $stmt->execute();
    $admin = $stmt->fetch();
    
    if ($admin) {
        echo "<p style='color: green;'>✅ Admin user found!</p>";
        echo "<p>Username: " . $admin['username'] . "</p>";
        echo "<p>Role: " . $admin['role'] . "</p>";
        echo "<p>Status: " . $admin['status'] . "</p>";
        
        // Test password verification
        if (password_verify('admin123', $admin['password'])) {
            echo "<p style='color: green;'>✅ Password 'admin123' works!</p>";
        } else {
            echo "<p style='color: red;'>❌ Password 'admin123' doesn't work. Fixing now...</p>";
            
            // Create new correct hash
            $new_hash = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE username = 'admin'");
            $stmt->execute([$new_hash]);
            
            echo "<p style='color: green;'>✅ Password updated! Try logging in again.</p>";
        }
        
    } else {
        echo "<p style='color: red;'>❌ Admin user not found! Creating now...</p>";
        
        // Create admin user
        $hash = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (student_id, full_name, email, username, password, role, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute(['ADMIN001', 'System Administrator', 'admin@adfc.edu', 'admin', $hash, 'admin', 'active']);
        
        echo "<p style='color: green;'>✅ Admin user created!</p>";
    }
    
    echo "<hr>";
    echo "<h3>Now try logging in with:</h3>";
    echo "<p><strong>Username:</strong> admin</p>";
    echo "<p><strong>Password:</strong> admin123</p>";
    echo "<p><a href='index.php' style='background: #1e549f; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>→ Try Login Again</a></p>";
    
} catch(Exception $e) {
    echo "<p style='color: red;'>Database Error: " . $e->getMessage() . "</p>";
    echo "<p>Make sure your database is imported correctly.</p>";
}
?>