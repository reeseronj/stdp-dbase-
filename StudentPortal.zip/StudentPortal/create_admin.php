<?php
// Simple script to create admin user with correct password
require_once 'config/database.php';

echo "<h2>Create Admin User</h2>";

try {
    // First, let's check if admin exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = 'admin'");
    $stmt->execute();
    $existing = $stmt->fetch();
    
    if ($existing) {
        echo "<p>Admin user exists. Updating password...</p>";
        // Update existing admin
        $password_hash = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE username = 'admin'");
        $stmt->execute([$password_hash]);
        echo "<p style='color: green;'>✅ Admin password updated!</p>";
    } else {
        echo "<p>Creating new admin user...</p>";
        // Create new admin
        $password_hash = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (student_id, full_name, email, username, password, role, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute(['ADMIN001', 'System Administrator', 'admin@adfc.edu', 'admin', $password_hash, 'admin', 'active']);
        echo "<p style='color: green;'>✅ Admin user created!</p>";
    }
    
    // Test the password
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = 'admin'");
    $stmt->execute();
    $admin = $stmt->fetch();
    
    if (password_verify('admin123', $admin['password'])) {
        echo "<p style='color: green;'>✅ Password verification successful!</p>";
    } else {
        echo "<p style='color: red;'>❌ Password verification failed!</p>";
    }
    
    echo "<hr>";
    echo "<h3>Login Credentials:</h3>";
    echo "<p><strong>Username:</strong> admin</p>";
    echo "<p><strong>Password:</strong> admin123</p>";
    echo "<p><a href='index.php' style='background: #1e549f; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>→ Go to Login Page</a></p>";
    
} catch(Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    echo "<p>Make sure your database is set up correctly.</p>";
}
?>